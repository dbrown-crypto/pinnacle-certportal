from datetime import date
from gate import (
    evaluate_gate, PolicySnapshot, CertRequest, PolicyStatus, SpecialWording
)

TODAY = date(2026, 6, 22)

def active_policy(**over):
    base = dict(
        policy_id="POL-1001",
        named_insured="T BROWN TRUCKING LLC",
        status=PolicyStatus.ACTIVE,
        effective_date=date(2026, 1, 1),
        expiration_date=date(2027, 1, 1),
        self_serve_enabled=True,
        coverages={"auto_liability": 1_000_000, "cargo": 100_000},
        data_current_as_of=date(2026, 6, 20),
    )
    base.update(over)
    return PolicySnapshot(**base)

def std_request(**over):
    base = dict(
        holder_name="ACME LOGISTICS BROKERAGE",
        holder_address="100 Dock St, Atlanta, GA 30301",
        holder_email="certs@acmelogistics.com",
        description_of_operations="Motor carrier hauling general freight.",
    )
    base.update(over)
    return CertRequest(**base)

def check(name, result, expect_route):
    ok = result.route == expect_route
    print(f"[{'PASS' if ok else 'FAIL'}] {name:42s} -> {result.route:16s} {result.audit_codes}")
    assert ok, f"{name}: expected {expect_route}, got {result.route}"

# Happy path
check("standard cert, active in-date policy",
      evaluate_gate(active_policy(), std_request(), TODAY), "auto_issue")

# Special wording routes to agent
check("additional insured requested",
      evaluate_gate(active_policy(),
                    std_request(requested_special_wording=[SpecialWording.ADDITIONAL_INSURED]),
                    TODAY), "route_to_agent")
check("waiver of subrogation requested",
      evaluate_gate(active_policy(),
                    std_request(requested_special_wording=[SpecialWording.WAIVER_OF_SUBROGATION]),
                    TODAY), "route_to_agent")

# Special wording wins even on a dead policy (Derrick still sees intent)
check("special wording on cancelled policy",
      evaluate_gate(active_policy(status=PolicyStatus.CANCELLED),
                    std_request(requested_special_wording=[SpecialWording.SPECIAL_LANGUAGE]),
                    TODAY), "route_to_agent")

# Kill switch
check("self-serve disabled (kill switch)",
      evaluate_gate(active_policy(self_serve_enabled=False), std_request(), TODAY), "block")

# Status gates
check("cancelled policy blocks",
      evaluate_gate(active_policy(status=PolicyStatus.CANCELLED), std_request(), TODAY), "block")
check("pending policy blocks",
      evaluate_gate(active_policy(status=PolicyStatus.PENDING), std_request(), TODAY), "block")

# Date gates — the quiet save
check("expired by date (status flag stale)",
      evaluate_gate(active_policy(expiration_date=date(2026, 5, 1)), std_request(), TODAY), "block")
check("not yet effective",
      evaluate_gate(active_policy(effective_date=date(2026, 12, 1)), std_request(), TODAY), "block")

# Data completeness
check("missing auto liability limit",
      evaluate_gate(active_policy(coverages={"cargo": 100_000}), std_request(), TODAY), "block")
check("zero auto liability limit",
      evaluate_gate(active_policy(coverages={"auto_liability": 0}), std_request(), TODAY), "block")

# Holder sanity
check("blank holder name",
      evaluate_gate(active_policy(), std_request(holder_name="  "), TODAY), "block")

print("\nAll gate scenarios behaved as designed.")
